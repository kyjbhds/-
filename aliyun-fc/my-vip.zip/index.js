const http = require('http');
const https = require('https');

let cachedToken = null;
let tokenExpireTime = 0;

function getTenantAccessToken(appId, appSecret) {
    return new Promise((resolve, reject) => {
        if (cachedToken && Date.now() < tokenExpireTime - 5 * 60 * 1000) {
            return resolve(cachedToken);
        }

        const data = JSON.stringify({
            app_id: appId,
            app_secret: appSecret
        });

        const options = {
            hostname: 'open.feishu.cn',
            port: 443,
            path: '/open-apis/auth/v3/tenant_access_token/internal',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        };

        const req = https.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => { body += chunk; });
            res.on('end', () => {
                try {
                    const result = JSON.parse(body);
                    if (result.code === 0) {
                        cachedToken = result.tenant_access_token;
                        tokenExpireTime = Date.now() + result.expire * 1000;
                        resolve(cachedToken);
                    } else {
                        reject(new Error(`获取token失败: ${result.msg}`));
                    }
                } catch (e) {
                    reject(e);
                }
            });
        });

        req.on('error', reject);
        req.write(data);
        req.end();
    });
}

function proxyToFeishu(path, method, token, body) {
    return new Promise((resolve, reject) => {
        const targetPath = `/open-apis/bitable/v1${path}`;
        const requestData = body ? JSON.stringify(body) : '';

        const options = {
            hostname: 'open.feishu.cn',
            port: 443,
            path: targetPath,
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
                ...(body ? { 'Content-Length': requestData.length } : {})
            }
        };

        const req = https.request(options, (res) => {
            let responseData = '';
            res.on('data', (chunk) => { responseData += chunk; });
            res.on('end', () => {
                resolve({
                    statusCode: res.statusCode,
                    data: responseData
                });
            });
        });

        req.on('error', reject);
        if (body) {
            req.write(requestData);
        }
        req.end();
    });
}

// 阿里云函数计算标准入口（HTTP触发器）
exports.handler = async function(event, context) {
    // 解析请求（兼容多种格式）
    let request;
    try {
        request = typeof event === 'string' ? JSON.parse(event) : event;
    } catch (e) {
        request = {};
    }
    
    const method = request.httpMethod || request.method || 'GET';
    const path = request.path || request.url || '/';
    const body = request.body || null;

    // 处理路径
    let targetPath = path;
    if (targetPath.startsWith('/api/bitable-proxy')) {
        targetPath = targetPath.replace('/api/bitable-proxy', '');
    }
    if (!targetPath) {
        targetPath = '/';
    }

    // 健康检查
    if (targetPath === '/' || targetPath === '/health') {
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            body: JSON.stringify({ status: 'ok', message: 'Proxy is running' }),
            isBase64Encoded: false
        };
    }

    try {
        const appId = process.env.FEISHU_APP_ID;
        const appSecret = process.env.FEISHU_APP_SECRET;

        if (!appId || !appSecret) {
            return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: 'Missing FEISHU credentials' }),
            isBase64Encoded: false
        };
        }

        const token = await getTenantAccessToken(appId, appSecret);

        let requestBody = null;
        if (body && method !== 'GET' && method !== 'HEAD') {
            try {
                requestBody = typeof body === 'string' ? JSON.parse(body) : body;
            } catch (e) {
                requestBody = body;
            }
        }

        const result = await proxyToFeishu(targetPath, method, token, requestBody);

        return {
            statusCode: result.statusCode,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            body: result.data,
            isBase64Encoded: false
        };
    } catch (error) {
        console.error('Proxy error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                error: 'Proxy request failed',
                message: error.message
            }),
            isBase64Encoded: false
        };
    }
};

// 本地开发测试用（监听端口）
if (require.main === module) {
    const server = http.createServer(async (req, res) => {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

        if (req.method === 'OPTIONS') {
            res.statusCode = 200;
            res.end('');
            return;
        }

        // 健康检查
        if (req.url === '/' || req.url === '/health') {
            res.statusCode = 200;
            res.end(JSON.stringify({ status: 'ok', message: 'Proxy is running' }));
            return;
        }

        try {
            const appId = process.env.FEISHU_APP_ID;
            const appSecret = process.env.FEISHU_APP_SECRET;

            if (!appId || !appSecret) {
                res.statusCode = 500;
                res.end(JSON.stringify({ error: 'Missing FEISHU credentials' }));
                return;
            }

            const token = await getTenantAccessToken(appId, appSecret);

            let body = null;
            if (req.method !== 'GET' && req.method !== 'HEAD') {
                let rawBody = '';
                req.on('data', (chunk) => { rawBody += chunk; });
                await new Promise((resolve) => req.on('end', resolve));
                if (rawBody) {
                    body = JSON.parse(rawBody);
                }
            }

            let path = req.url;
            if (path.startsWith('/api/bitable-proxy')) {
                path = path.replace('/api/bitable-proxy', '');
            }
            if (!path) {
                path = '/';
            }
            
            const result = await proxyToFeishu(path, req.method, token, body);

            res.statusCode = result.statusCode;
            res.end(result.data);
        } catch (error) {
            console.error('Proxy error:', error);
            res.statusCode = 500;
            res.end(JSON.stringify({
                error: 'Proxy request failed',
                message: error.message
            }));
        }
    });

    const PORT = process.env.PORT || 3000;
    server.listen(PORT, '0.0.0.0', () => {
        console.log(`Server running on port ${PORT}`);
    });
}
